/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concertbooking;

/**
 *
 * @author Stuart
 */
public class Seat_Bronze extends Seat{

    public Seat_Bronze(){
    
        //Sets the seats colour to bronze.
        this.setBackground(new java.awt.Color(255, 104, 104));
        this.setType("bronze");
        
    }

}
