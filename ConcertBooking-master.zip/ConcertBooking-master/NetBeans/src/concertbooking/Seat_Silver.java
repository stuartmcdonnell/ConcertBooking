/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package concertbooking;

/**
 *
 * @author Stuart
 */
public class Seat_Silver extends Seat{
    
    public Seat_Silver(){
        
         //Sets the seats colour to silver.
        this.setBackground(new java.awt.Color(131, 131, 131));
        this.setType("silver");
    
    }
    
}
